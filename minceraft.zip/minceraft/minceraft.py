from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
import time
import random

app = Ursina(title="Minceraft")
player = FirstPersonController(height=1)
Sky()

# Settings
application.show_ursina_splash = True
window.icon = 'external/rose.ico'
window.title = 'Minceraft'
window.borderless = False
window.fullscreen = False
window.vsync = False

# Cursor
mouse.visible = False
player.cursor.scale = .008
player.cursor.color = color.white

boxes = []

block_types = [
    ('grass', 'textures/grass.png'),
    ('cobblestone', 'textures/cobblestone.png'),
    ('stone', 'textures/stone.png'),
    ('coal ore', 'textures/coal_ore.png'),
    ('iron ore', 'textures/iron_ore.png'),
    ('gold ore', 'textures/gold_ore.png'),
    ('obsidian', 'textures/obsidian.png'),
    ('dirt', 'textures/dirt.png'),
    ('sponge', 'textures/sponge.png'),
    ('leaves', 'textures/leaves.png'),
    ('rose', 'textures/rose.png'),
    ('aetherrose', 'textures/aether_rose.png'),
    ('dandelion', 'textures/yellow_flower.png'),
    ('sapling', 'textures/sapling.png'),
    ('sugarcane', 'textures/sugarcane.png'),
    ('redstone torch', 'textures/redstonetorch.png'), # End of organic/redstone
    ('netherrack', 'textures/netherrack.png'),
    ('wood', 'textures/wood.png'),
    ('birchwood', 'textures/birchwood.png'),
    ('sprucewood', 'textures/sprucewood.png'),
    ('planks', 'textures/planks.png'),
    ('bricks', 'textures/brick.png'),
    ('slab', 'textures/planks.png'),
    ('glass', 'textures/glass.png'),
    ('sand', 'textures/sand.png'),
    ('gravel', 'textures/gravel.png'),
    ('ice', 'textures/ice.png'),
    ('snow', 'textures/snow.png'), # End of natural
    ('wool', 'textures/wool.png'),
    ('ironblock', 'textures/ironblock.png'),
    ('goldblock', 'textures/goldblock.png'),
    ('diamondblock', 'textures/diamondblock.png'),
    ('nether_reactor', 'textures/nether_reactor.png\statue', 'textures/steve.png'),
    ('philmahar', 'textures/phil_mahar.jpg'),
    ('statue', 'textures/steve.png'),
    ('info_update1', 'textures/update.png'),
    ('info_update2', 'textures/update2.png'),  # End of misc
]

current_block_index = 0

# Create the ground layer
for i in range(15):
    for j in range(15):
        box = Button(color=color.white, model='cube', position=(j, 0, i),
                     texture=block_types[current_block_index][1], parent=scene, origin_y=0.5)
        boxes.append(box)

# Create additional layers
for layer in range(4):
    for i in range(15):
        for j in range(15):
                box = Button(color=color.white, model='cube', position=(j, -layer - 1, i),
                    texture='textures/stone.png', parent=scene, origin_y=0.5)
                boxes.append(box)

def input(key):
    global current_block_index

    if key == 'j':
        current_block_index = (current_block_index - 1) % len(block_types)
        print(f"Selected block: {block_types[current_block_index][0]} with block index of {current_block_index}")

    if key == 'k':
        current_block_index = (current_block_index + 1) % len(block_types)
        print(f"Selected block: {block_types[current_block_index][0]} with block index of {current_block_index}")

    if key == 'left mouse down':
        for box in boxes:
            if box.hovered:
                if current_block_index in [10, 11, 12, 13, 14, 15]:
                    new = Button(color=color.white, model='models/flower', position=box.position + mouse.normal,
                                 texture=block_types[current_block_index][1], parent=scene, origin_y=0.9)
                elif current_block_index == 22:
                    new = Button(color=color.white, model='models/slab', position=box.position + mouse.normal,
                                 texture=block_types[current_block_index][1], parent=scene, origin_y=1)
                elif current_block_index == 34:
                    new = Button(color=color.white, model='models/player', position=box.position + mouse.normal,
                                 texture=block_types[current_block_index][1], parent=scene, origin_y=1)
                else:
                    new = Button(color=color.white, model='cube', position=box.position + mouse.normal,
                                 texture=block_types[current_block_index][1], parent=scene, origin_y=0.5)
                
                boxes.append(new)
                break

    if key == 'right mouse down':
        for box in boxes:
            if box.hovered:
                boxes.remove(box)
                destroy(box)
                break
    if key == 'r':
        player.position = (player.position.x, player.position.z + 20, player.position.z)

app.run(60)
